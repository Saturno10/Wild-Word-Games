#include "Utilidades.h"

using namespace std;

DicPalabras d;

int main(){

    InterpreteComandos(d);

    return 0;
}
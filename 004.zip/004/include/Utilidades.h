#ifndef UTILIDADES_H
#define UTILIDADES_H


class Utilidades
{
    public:
        Utilidades();
        virtual ~Utilidades();

        /*
         
         
         ESTO ES PARA AÑADIR EN LA CLASE LA LA FUNCION DE LAS MAYUSCULAS Y EL INTERPRETE
        */

    protected:

    private:
};

#endif // UTILIDADES_H

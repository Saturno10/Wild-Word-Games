#include "Utilidades.h"

Utilidades::Utilidades()
{
    //ctor
}

Utilidades::~Utilidades()
{
    //dtor
}
